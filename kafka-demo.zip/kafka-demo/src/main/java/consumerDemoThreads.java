import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.time.Duration;
import java.util.Arrays;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;
import java.util.logging.Logger;

public class consumerDemoThreads {

    public static void main(String[] args) {
    new ConsumeDemoThreads().run();

    }

    private static class ConsumeDemoThreads{
        public void run(){
            System.out.println("HELLO");
            Logger logger = Logger.getLogger(consumerDemoThreads.class.getName());

            String group_id = "my_third_application";
            String bootstrap_server = "127.0.0.1:9092";
            String topic = "first_topic";
            CountDownLatch latch= new CountDownLatch(1);
            Runnable myconsumerThread = new ConsumerThread(bootstrap_server,topic,group_id,latch);

            // start the thread
            Thread myThread = new Thread(myconsumerThread);
            myThread.start();

            try {
                latch.await();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


    public static class ConsumerThread implements Runnable{
        private CountDownLatch latch;
        private KafkaConsumer<String,String> consumer;
        private Logger logger = Logger.getLogger(ConsumerThread.class.getName());

        public ConsumerThread(String bootstrap_server, String topic, String group_id,CountDownLatch latch){
            this.latch = latch;
            /*Property setup*/
            Properties prop = new Properties();
            prop.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,bootstrap_server);
            prop.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
            prop.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
            prop.setProperty(ConsumerConfig.GROUP_ID_CONFIG,group_id);
            prop.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest");//earliest,latest, none
            consumer= new KafkaConsumer<String,String>(prop);
            consumer.subscribe(Arrays.asList(topic));

        }

        @Override
        public void run() {

            //Poll
            try {
                while (true) {
                    ConsumerRecords<String, String> record = consumer.poll(Duration.ofMillis(100));

                    for (ConsumerRecord<String, String> rec : record) {
                        logger.info("Topic:" + rec.topic());
                        logger.info("Key:" + rec.key());
                        logger.info("Value:" + rec.value());
                        logger.info("Offset:" + rec.offset());
                        logger.info("Partition:" + rec.partition());
                        logger.info("Timestamp:" + rec.timestamp());

                    }
                }
            }
            catch(WakeupException e){

                logger.info("Received shutdown signal");

            }
            finally{
                consumer.close();
                latch.countDown();
            }
        }

        public void shutdown(){
            consumer.wakeup();//to interrupt consumer.poll and throw wakeupException
        }
    }


}
