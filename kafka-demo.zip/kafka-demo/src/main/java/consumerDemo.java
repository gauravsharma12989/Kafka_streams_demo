import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;

import java.time.Duration;
import java.util.Arrays;
import java.util.Properties;
import java.util.logging.Logger;

public class consumerDemo {

    public static void main(String[] args) {
        System.out.println("HELLO");
        Logger logger = Logger.getLogger(consumerDemo.class.getName());
        /*Property setup*/
        Properties prop = new Properties();
        String group_id = "my_second_application";


        String bootstrap_server = "127.0.0.1:9092";
        prop.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,bootstrap_server);
        prop.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        prop.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        prop.setProperty(ConsumerConfig.GROUP_ID_CONFIG,group_id);
        prop.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest");//earliest,latest, none

        /*Create Consumer*/

        KafkaConsumer<String,String> consumer= new KafkaConsumer<String,String>(prop);

        consumer.subscribe(Arrays.asList("first_topic"));

        //Poll
        while(true){
            ConsumerRecords<String,String> record = consumer.poll(Duration.ofMillis(100));

            for (ConsumerRecord<String,String> rec : record){
                logger.info("Topic:"+rec.topic());
                logger.info("Key:"+rec.key());
                logger.info("Value:"+rec.value());
                logger.info("Offset:"+rec.offset());
                logger.info("Partition:"+rec.partition());
                logger.info("Timestamp:"+rec.timestamp());

            }
        }

    }
}
