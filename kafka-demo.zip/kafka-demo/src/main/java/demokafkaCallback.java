import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class demokafkaCallback {

    public static void main(String[] args) {
       // System.out.println("HELLO  WORLD");
        String msg = "Hello There";
        Logger  logger = LoggerFactory.getLogger(ProducerRecord.class);

        //Create Producer Properties
        Properties prop = new Properties();
        String bootstrap_server = "127.0.0.1:9092";
        prop.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,bootstrap_server);
        prop.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        prop.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());

        //Create the producer
        KafkaProducer<String,String> producer = new KafkaProducer<String,String>(prop);

        for(int i=0; i<100; i++) {
            //Create the producer record
            ProducerRecord<String, String> record = new ProducerRecord<String, String>("second_topic", msg+i);

            //send data
            producer.send(record, new Callback() {
                @Override
                public void onCompletion(RecordMetadata recordMetadata, Exception e) {
                    if (e == null) {
                        logger.info("Received new record" + "\n" +
                                recordMetadata.offset() + "\n" +
                                        recordMetadata.partition() + "\n" +
                                        recordMetadata.topic() + "\n" +
                                        recordMetadata.timestamp());
                    } else {
                        logger.error("Error while producing ", e);
                    }
                }
            });
        }
        producer.flush();
        producer.close();

    }
}
