import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;

public class customer_records_stub {

    public static void main(String[] args) {  // kafka bootstrap server

        Properties properties = new Properties();
        properties.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9092");
        properties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        properties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        // producer acks
        properties.setProperty(ProducerConfig.ACKS_CONFIG, "all"); // strongest producing guarantee
        properties.setProperty(ProducerConfig.RETRIES_CONFIG, "3");
        properties.setProperty(ProducerConfig.LINGER_MS_CONFIG, "1");
        // leverage idempotent producer from Kafka 0.11 !
        properties.setProperty(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, "true"); // ensure we don't push duplicates

        Producer<String, String> producer = new KafkaProducer<>(properties);

        System.out.println("Producing batch: ");

        producer.send(newRandomTransaction("4477889911"));
        //producer.send(newRandomTransaction("98765421"));
        // producer.send(newRandomTransaction("4477889911"));


        producer.close();
    }

    public static ProducerRecord<String, String> newRandomTransaction(String acctno) {
        // creates an empty json {}
        ObjectNode transaction = JsonNodeFactory.instance.objectNode();


        int number_cust = 2;
        int sub_alerts=3;


        ArrayList<Object>[] customers = new ArrayList[number_cust];

        for(int i =0; i<number_cust ;i++){
            customers[i] = new ArrayList<>();

        }

        ArrayList<String>[] demographic = new ArrayList[number_cust];

        for(int i =0; i<number_cust ;i++){
            demographic[i] = new ArrayList<String>();

        }

        ArrayList<String>[][] subscription = new ArrayList[number_cust][sub_alerts];

        for(int i =0; i<number_cust ;i++){
            for(int k=0; k<sub_alerts;k++)
            subscription[i][k] = new ArrayList<String>();

        }
        demographic[0].add("+91");
        demographic[0].add("");
        demographic[0].add("9540596309");

        demographic[1].add("+91");
        demographic[1].add("");
        demographic[1].add("9540596309");

        subscription[0][0].add("sub1");
        subscription[0][0].add("sub2");
        subscription[0][0].add("sub3");
        subscription[0][1].add("sub1");
        subscription[0][1].add("sub2");
        subscription[0][1].add("sub3");
        subscription[0][2].add("sub1");
        subscription[0][2].add("sub2");
        subscription[0][2].add("sub3");

        subscription[1][0].add("sub1");
        subscription[1][0].add("sub2");
        subscription[1][0].add("sub3");
        subscription[1][1].add("sub1");
        subscription[1][1].add("sub2");
        subscription[1][1].add("sub3");
        subscription[1][2].add("sub1");
        subscription[1][2].add("sub2");
        subscription[1][2].add("sub3");


        customers[0].add("98765432"); //custno
        customers[0].add("P"); //Primary
        customers[0].add(demographic[0]);
        customers[0].add(subscription[0]);
        customers[1].add("12345678"); //custno
        customers[1].add("S"); //Primary
        customers[1].add(demographic[1]);
        customers[1].add(subscription[1]);

        ObjectMapper fi = new ObjectMapper();
        ArrayNode array = fi.valueToTree(customers);
        //ObjectNode companyNode = mapper.valueToTree(company)

        // we write the data to the json document
        transaction.put("customers", array);

        System.out.println(transaction.toString());
        //Add : primary customer,

       // return null;

       return new ProducerRecord<>("customer_data", acctno, transaction.toString());
    }

}
