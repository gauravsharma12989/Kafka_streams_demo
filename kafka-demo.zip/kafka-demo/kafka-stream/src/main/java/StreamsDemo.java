import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Printed;

import java.util.Properties;

public class StreamsDemo {

    public static void main(String[] args) {
        //Create properties

        Properties prop = new Properties();
        prop.setProperty(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG,"127.0.0.1:9092");
       // prop.setProperty(StreamsConfig.APPLICATION_ID_CONFIG,"first_application");
        prop.setProperty(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.StringSerde.class.getName());
        prop.setProperty(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG,Serdes.StringSerde.class.getName());
        prop.setProperty(StreamsConfig.APPLICATION_ID_CONFIG,"my_second_application");//earliest,latest, none
        //build topology
        StreamsBuilder builder = new StreamsBuilder();
    //while(true) {
        KStream<String, String> first = builder.stream("first_topic");
        first.print(Printed.toSysOut());
   // }

    }
}
