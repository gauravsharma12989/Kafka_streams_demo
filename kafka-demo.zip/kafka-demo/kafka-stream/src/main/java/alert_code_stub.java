import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;

public class alert_code_stub {

    public static void main(String[] args) {
        Properties properties = new Properties();

        // kafka bootstrap server
        properties.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9092");
        properties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        properties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        // producer acks
        properties.setProperty(ProducerConfig.ACKS_CONFIG, "all"); // strongest producing guarantee
        properties.setProperty(ProducerConfig.RETRIES_CONFIG, "3");
        properties.setProperty(ProducerConfig.LINGER_MS_CONFIG, "1");
        // leverage idempotent producer from Kafka 0.11 !
        properties.setProperty(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, "true"); // ensure we don't push duplicates

        Producer<String, String> producer = new KafkaProducer<>(properties);

        System.out.println("Producing batch: ");

        producer.send(newRandomTransaction("CARD_DECLINED"));
        //producer.send(newRandomTransaction("98765421"));
        // producer.send(newRandomTransaction("4477889911"));


        producer.close();
    }

    public static ProducerRecord<String, String> newRandomTransaction(String cardno) {
        // creates an empty json {}
        ObjectNode transaction = JsonNodeFactory.instance.objectNode();

        // { "amount" : 46 } (46 is a random number between 0 and 100 excluded)
        Integer amount = ThreadLocalRandom.current().nextInt(0, 100);
        String pos = "81";
        // if(amount < 50) pos = "01";

        // Instant.now() is to get the current time using Java 8
        Instant now = Instant.now();
        int number_conditions = 4;
        int number_variables = 2;

        ArrayList<String>[] fields = new ArrayList[number_conditions];

        for(int i =0; i<number_conditions ;i++){
        fields[i] = new ArrayList<String>();

        }

        ArrayList<String>[] variables = new ArrayList[number_variables];

        for(int i =0; i<number_variables ;i++){
            variables[i] = new ArrayList<String>();

        }

        fields[0].add("pos_entry_mode");
        fields[0].add("N");
        fields[0].add("isinList");
        fields[0].add("80,81");
        fields[1].add("Rev_code");
        fields[1].add("N");
        fields[1].add("");
        fields[1].add("");
        fields[2].add("Card_txn_Org");
        fields[2].add("N");
        fields[2].add("isinList");
        fields[2].add("888");
        fields[3].add("Transaction_Type");
        fields[3].add("N");
        fields[3].add("isinList");
        fields[3].add("390,980");

        variables[0].add("var1");
        variables[0].add("TransactionDate");
        variables[1].add("var2");
        variables[1].add("Last4Digit");

        String template = "your transaction dated <var1> by card ending <var2> has been declined.";

        ObjectMapper fi = new ObjectMapper();
        ArrayNode array = fi.valueToTree(fields);
        ArrayNode array2 = fi.valueToTree(variables);
        //ObjectNode companyNode = mapper.valueToTree(company)

        // we write the data to the json document
        transaction.put("fields", array);
        transaction.put("variables", array2);
        transaction.put("template", template);
        transaction.put("Subscribed_alert", "N");
        transaction.put("sendEmail","N");
        transaction.put("sendSMS","Y");
        transaction.put("sendToPrimaryOnly","N");
        transaction.put("alert_type","CARD_TXN");
        transaction.put("alert_name","INVALIDCVV");

        System.out.println(transaction.toString());

       return new ProducerRecord<>("cae_alert_code", cardno, transaction.toString());
    }

}