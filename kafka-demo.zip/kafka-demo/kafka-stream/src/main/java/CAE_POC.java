import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.serialization.Serializer;
import org.apache.kafka.connect.json.JsonDeserializer;
import org.apache.kafka.connect.json.JsonSerializer;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.*;


import java.util.Properties;

public class CAE_POC {

    public Topology createTopology(){
        StreamsBuilder builder = new StreamsBuilder();
        // 1 - stream from Kafka
        final Serializer<JsonNode> txn_ser = new JsonSerializer();
        final Deserializer<JsonNode> txn_des = new JsonDeserializer();

        final Serde<JsonNode> jsonserde = Serdes.serdeFrom(txn_ser,txn_des);

        KStream<String, JsonNode> txn = builder.stream("cae_afews_txn", Consumed.with(Serdes.String(),jsonserde));
        GlobalKTable<String,JsonNode> cards_alerts = builder.globalTable("cae_alert_code", Consumed.with(Serdes.String(),jsonserde));
        GlobalKTable<String,JsonNode> customer_data = builder.globalTable("customer_data", Consumed.with(Serdes.String(),jsonserde));
      // KTable<String,JsonNode> cards_alerts = builder.table("cae_alert_code_table",Consumed.with(Serdes.String(),jsonserde));
      // KStream<String, JsonNode> all_alerts = builder.stream("cae_alert_code_table", Consumed.with(Serdes.String(),jsonserde)).selectKey((key,value)-> value.get("alert_type").asText());
        /*The limitations: alerts need to be categorized and keyed . Need to be maintained as lists */

      //  KTable<String, String> table = builder.table("input-topic", Consumed.with(Serdes.String(), Serdes.String()));
      // KStream<String,JsonNode> alert_Stream = cards_alerts.toStream().selectKey((key,value)-> value.get("alert_type").asText());
     // alert_Stream.to("cae_table_topic", Produced.with(Serdes.String(), jsonserde));

    //Make sure data is co-partitioned (same number of partitions in GlobalKTable and KStream) */

        KStream<String, JsonNode> card_bank = txn.join(customer_data,(key,value) -> key, //inner join
                (txndata,customer) -> ((ObjectNode) txndata).putAll((ObjectNode)customer)).selectKey((key,value) -> {
            if(value.get("Transaction_family_bank_card").asText().equals("Card") && value.get("Decline_reason_code").asInt() != 0) return "CARD_DECLINED";
            else if(value.get("Transaction_family_bank_card").asText().equals("Card") && value.get("Decline_reason_code").asInt() == 0) return "CARD_SUCCESS";
            else if(value.get("Transaction_family_bank_card").asText().equals("Bank") && value.get("Credit_or_debit_Indicator").asText() == "D") return "BANK_OUTFLOW";
            else if(value.get("Transaction_family_bank_card").asText().equals("Bank") && value.get("Credit_or_debit_Indicator").asText() == "C") return "BANK_INFLOW";
            else return null;

        }).join(cards_alerts,(key,value) -> key,(txndata,alertsdata) -> ((ObjectNode) txndata).putAll((ObjectNode)alertsdata));





        //  System.out.println("GauravTest1");
    /*
      KStream<String,JsonNode> card_alerts = card_bank.flatMapValues(value -> {
          try {
              return IdentifyCardAlerts(value);
          } catch (Exception e) {
              e.printStackTrace();
          }
          return null;
      }).filter((key,value)-> value != null); */

        //KStream<String,String> alert = txn.map((key,value) -> ("Hi","Hello"));
        KStream<String,JsonNode> card_alerts = card_bank.mapValues((key,value) -> IdentifyCardAlerts(value)).filter((key,value)-> value!=null);


        // 7 - to in order to write the results back to kafka
       // card_alerts.to("alert_output", Produced.with(Serdes.String(), jsonserde));
        card_alerts.to("alert_output", Produced.with(Serdes.String(), jsonserde));
        //  card_bank.to("alert_output", Produced.with(Serdes.String(), jsonserde));

        return builder.build();
    }

    private JsonNode IdentifyCardAlerts(JsonNode value) {
        //System.out.println("GauravTest2");
        ObjectNode alert_msg = JsonNodeFactory.instance.objectNode();
        //String alert_msg = "Not satisfied";
        //String pos = "pos_entry_mode";
        // String amt = "Transaction_Amount";
        System.out.println(value);
    /*
       String code = "{\"fields\":[[\"pos_entry_mode\",\"N\",\"isinList\",\"00,81\"],[\"Rev_code\",\"Y\",\"\",\"\"],[\"Card_txn_Org\",\"N\",\"isinList\",\"888\"],[\"Transaction_Type\",\"N\",\"isinList\",\"390,980\"]],\"variables\":[[\"var1\",\"TransactionDate\"],[\"var2\",\"Last4Digit\"]],\"template\":\"your transaction dated <var1> by card ending <var2> has been declined.\",\"Subscribed_alert\":\"N\"}";
        ObjectMapper mapper = new ObjectMapper();
        JsonNode alert = null;
        try {
            alert = mapper.readTree(code);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        */
        /*Check all conditions*/
        /*replace variables*/
        /*Check if subscribed alert*/
        /*Send message*/

        String drop_reason = "";

        // if(alert.get("Subscribed_alert").asText().equals("Y") && value.get(""))

        final JsonNode fields = value.get("fields");
        final JsonNode variables = value.get("variables");
        if (fields.isArray()) {
            for (final JsonNode condition : fields) {
                if(condition.get(1).asText().equals("N") && isNullBlank(value.get(condition.get(0).asText()).asText()))
                {
                    System.out.println("Failed condition: "+condition.get(0).asText());

                    drop_reason = condition.get(0).asText() + " field is NullBlank.";
                    break;
                }
                if(condition.get(1).asText().equals("Y") && !isNullBlank(value.get(condition.get(0).asText()).asText()))
                {
                    System.out.println("Failed condition: "+condition.get(0).asText());

                    drop_reason = condition.get(0).asText() + " field is not NullBlank.";
                    break;
                }
                try {
                    if (!isNullBlank(condition.get(2).asText()) && !evaluate(value.get(condition.get(0).asText()).asText(), condition.get(2).asText(), condition.get(3).asText())) {
                        System.out.println(condition.get(2).asText() + " " + value.get(condition.get(0).asText()).asText() + " " + condition.get(2).asText() + " " + condition.get(3).asText());

                        drop_reason = condition.get(0).asText() + " field value is not satisfied.";
                        break;
                    }
                }
                catch(NullPointerException ex){
                    System.out.println("Condition for field "+condition.get(0)+" has no operator and value. Only null check done");
                }


            }
        }

        String msg = "";

        if(isNullBlank(drop_reason)){
            msg = value.get("template").asText();
          //  System.out.println(msg);

            for (final JsonNode var : variables) {
                msg =msg.replace("<"+var.get(0).asText()+">",value.get(var.get(1).asText()).asText());
            }
            //check suscription data/SMS/EMAIL
            //check primary
            // alert_msg.put("custno",value.get("customers").get(0));
            alert_msg.put("alert_name",value.get("alert_name").asText());
            alert_msg.put("Message",msg);
        }else{
            //send to Mongo DB
            System.out.println(drop_reason);
            alert_msg = null;
        }




        return alert_msg;



    }

    private boolean evaluate(String value,  String operator,String list) {
        if(operator.toLowerCase().equals("isinlist")){
            //System.out.println(value+":"+list+":"+operator);
            return isinList(value,list);
        }
        if(operator.toLowerCase().equals("isequal")){
            return isEqual(value,list);
        }
        if(operator.toLowerCase().equals("isgreaterthan")){
            return isGreaterThan(value,list);
        }
        if(operator.toLowerCase().equals("islessthan")){
            return (!isGreaterThan(value,list) && !isEqual(value,list));
        }



        return false;
    }

    private boolean isGreaterThan(String value, String list) {
        try {
            return Long.parseLong(value) > Long.parseLong(list);
        }
        catch(Exception ex){
            System.out.println("Error while converting to long "+value+" "+list);
        }
        return false;
    }

    private boolean isEqual(String value, String list) {
        try {
            return Long.parseLong(value) == Long.parseLong(list);
        }
        catch(Exception ex){
            System.out.println("Error while converting to long "+value+" "+list);
        }
        return false;
    }

    private boolean isinList(String value, String list) {
        return list.contains(value);
    }

    private boolean isNullBlank(String field) {
        return (field == "" || field == null);
    }

    public static void main(String[] args) {
        Properties config = new Properties();
        config.put(StreamsConfig.APPLICATION_ID_CONFIG, "cae_poc_config2");
        config.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9092");
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        // config.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        // Exactly once processing!!
        config.put(StreamsConfig.PROCESSING_GUARANTEE_CONFIG, StreamsConfig.EXACTLY_ONCE);

        final Serializer<JsonNode> txn_ser = new JsonSerializer();
        final Deserializer<JsonNode> txn_des = new JsonDeserializer();

        final Serde<JsonNode> jsonserde = Serdes.serdeFrom(txn_ser,txn_des);
        // config.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, jsonserde);

        CAE_POC cae_poc = new CAE_POC();

        KafkaStreams streams = new KafkaStreams(cae_poc.createTopology(), config);
        streams.start();

        // shutdown hook to correctly close the streams application
        Runtime.getRuntime().addShutdownHook(new Thread(streams::close));

        // Update:
        // print the topology every 10 seconds for learning purposes
        while(true){
            streams.localThreadsMetadata().forEach(data -> System.out.println(data));
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                break;
            }
        }


    }
}
